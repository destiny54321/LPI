package com.ipl.dao;

import com.ipl.bean.StaticData.StaticDataBean;

public interface StaticDataDao
{
	StaticDataBean getStaticData();
}
