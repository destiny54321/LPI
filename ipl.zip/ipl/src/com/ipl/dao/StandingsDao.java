package com.ipl.dao;

import java.util.ArrayList;

import com.ipl.bean.UserPointsBean;

public interface StandingsDao
{
    public ArrayList<UserPointsBean> getAllStandings();
}
