package com.ipl.bean.StaticData;

public class MatchFixturesBean
{
    private int matchFixturesId;

    private int teamOneId;

    private String teamOneCode;
   
    private int teamTwoId;

    private String teamTwoCode;
    
    private int teamWinId;
    
    private String teamWinCode;

    private String matchDateTime;
    
    private int venueId;
    
    private String venueName;
    
    private String venueCity;
    
    private String MatchStatus;
    
	public int getMatchFixturesId() {
		return matchFixturesId;
	}

	public void setMatchFixturesId(int matchFixturesId) {
		this.matchFixturesId = matchFixturesId;
	}

	public int getTeamOneId() {
		return teamOneId;
	}

	public void setTeamOneId(int teamOneId) {
		this.teamOneId = teamOneId;
	}

	public String getTeamOneCode() {
		return teamOneCode;
	}

	public void setTeamOneCode(String teamOneCode) {
		this.teamOneCode = teamOneCode;
	}

	public int getTeamTwoId() {
		return teamTwoId;
	}

	public void setTeamTwoId(int teamTwoId) {
		this.teamTwoId = teamTwoId;
	}

	public String getTeamTwoCode() {
		return teamTwoCode;
	}

	public void setTeamTwoCode(String teamTwoCode) {
		this.teamTwoCode = teamTwoCode;
	}

	public int getTeamWinId() {
		return teamWinId;
	}

	public void setTeamWinId(int teamWinId) {
		this.teamWinId = teamWinId;
	}

	public String getTeamWinCode() {
		return teamWinCode;
	}

	public void setTeamWinCode(String teamWinCode) {
		this.teamWinCode = teamWinCode;
	}

	public String getMatchDateTime() {
		return matchDateTime;
	}

	public void setMatchDateTime(String matchDateTime) {
		this.matchDateTime = matchDateTime;
	}

	public int getVenueId() {
		return venueId;
	}

	public void setVenueId(int venueId) {
		this.venueId = venueId;
	}

	public String getVenueName() {
		return venueName;
	}

	public void setVenueName(String venueName) {
		this.venueName = venueName;
	}

	public String getVenueCity() {
		return venueCity;
	}

	public void setVenueCity(String venueCity) {
		this.venueCity = venueCity;
	}

	public String getMatchStatus() {
		return MatchStatus;
	}

	public void setMatchStatus(String matchStatus) {
		MatchStatus = matchStatus;
	}
    
}
