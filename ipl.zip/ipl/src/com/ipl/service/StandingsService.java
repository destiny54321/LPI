package com.ipl.service;

import java.util.ArrayList;

import com.ipl.bean.UserPointsBean;

public interface StandingsService
{

	ArrayList<UserPointsBean> getPointsTable();

 }
