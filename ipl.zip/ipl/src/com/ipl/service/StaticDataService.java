package com.ipl.service;

import com.ipl.bean.StaticData.StaticDataBean;

public interface StaticDataService
{

    StaticDataBean populateStaticData();

}
